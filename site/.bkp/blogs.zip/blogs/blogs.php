<?
##
function GetUserMsgs( $uid = 1 )
{
	$sql = "SELECT mTheme, mMsg, mId, mDate, fName, fDesc FROM msgs, forums WHERE mAccess='p' AND mUid=$uid AND mFid=fId";
	$res = uquery($sql);
	for( $result = array(); $row = mysql_fetch_array($res);$result[] = $row );
	if( mysql_num_rows($res) ) return $result;
	return 0;
}

##
function ShowPreviev( $msg )
{
	$res = "<table style='width:100%;margin:5px;'>";
	$res.= "<tr><td><a href='main.php?script=showpost&mid={$msg['mId']}' class='bl_main'>{$msg['mTheme']}</a><br>";
	$res.= " &nbsp; <span style='text-decoration:underline;'>{$msg['fDesc']}</span><br><br></td></tr>";
	$res.= "<tr><td></td></tr>";
	
	$text = substr( $msg['mMsg'],0,500 );
	$pos = strrpos($text, " " );
	if( $pos ) $text = substr( $text, 0, $pos );
	
	$res.= "<tr><td>$text<br><span style='float:right;color:#cc66ff;'>{$msg['mDate']}</span><br><br></td></tr>";
	$res.= "</table>";
	
	return $res;
}

## Get next blog message
function GetNextMsgId( $mid, $uid )
{
	$sql = "SELECT mId FROM msgs WHERE mAccess='p' AND mUid=$uid AND mId > $mid";
	$res = uquery($sql);
	if(  mysql_num_rows($res) ) return mysql_result($res, 0, 0);
	return 0;
}

## Get prev blog message
function GetPrevMsgId( $mid, $uid )
{
	$sql = "SELECT mId FROM msgs WHERE mAccess='p' AND mUid=$uid AND mId < $mid";
	$res = uquery($sql);
	if(  mysql_num_rows($res) ) return mysql_result($res, 0, 0);
	return 0;
}

?>