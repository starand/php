<?
	include_once "../files/common.php";
	
	if( !isset($_SESSION['userId']) || !$_SESSION['userId'] ) $_SESSION['userId'] = 1;
	
	if( !isset($_SESSION['script']) ) $_SESSION['script'] = "lastposts";
	if( isset($_GET['script']) ) $_SESSION['script'] = $_GET['script'];
	
	$user = GetUser( 2 );
	
?>
<HEAD>
	<LINK href='<? echo style()."main.css"; ?>' rel=stylesheet type=text/css>
	<meta http-equiv='Content-Type' content='text/html; charset=windows-1251'>
</HEAD>
<BODY style='background:#69217A;'>

<center>
<script language=javascript src='../files/main.js'></script>
<div style='margin:0px; padding:0px; position: relative;width:1262;'>

<table style='width:1024px;'>
	<tr>
		<td>
			<div style='font-size:24px;margin:5px;color:magenta;text-align:right;'>StarAnd blog</div>
			<span style='float:left;'>
				<a href='main.php?script=lastposts' class='bl_menu'>Posts</a>
			</span>
			<span style='float:right;'>
				<a class='bl_menu'>LogIn</a> | 
				<a class='bl_menu'>Register</a>
			</span>
			<br><hr>
		</td>
	</tr>
	<tr>
		<td>
		<? 
			switch( $_SESSION['script'] )
			{
			case 'showpost':
				include_once "showpost.php";
				break;
			case 'lastposts' :
			default:
				include_once "lastposts.php";
				break;
			}

		?>
		</td>
	</tr>
</table>

</BODY>