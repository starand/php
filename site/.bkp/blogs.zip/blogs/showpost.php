<?
	if( !defined("COMMON") ) die();
	include_once "blogs.php";
	include_once "../forums/forums.php";
	
	if( !isset($_SESSION['mid']) || !$_SESSION['mid'] ) $_SESSION['mid'] = 3672;
	$mId = @ (int)$_GET['mid']; if( $mId ) $_SESSION['mid'] = $mId;
	
	$msg = GetMsg( $_SESSION['mid'] ); if( !$msg ) die();
?>
<link href="/forums/css/shCore.css" rel="stylesheet" type="text/css" />
<link href="/forums/css/shThemeFadeToGrey.css" rel="stylesheet" type="text/css" />
<?
	echo "<script type='text/javascript' src='../forums/js/shCore.js'></script>";
	foreach($langs as $lang) echo "<script type='text/javascript' src='/forums/js/shBrush$lang.js'></script>";
	echo "<div style='padding:10px;'><h2>{$msg['mTheme']}</h2>{$msg['mMsg']}</div>";
	
	$nextId = GetNextMsgId( $msg[mId], $_SESSION['userId'] );
	$prevId = GetPrevMsgId( $msg[mId], $_SESSION['userId'] );
	
	if( $prevId ) echo "<a href='main.php?script=showpost&mid=$prevId' class='bl_main'> &lt; Prev</a>";
	else echo "<a class='bl_main_grey'> &lt; Prev</a>";
	echo " &nbsp; ";
	
	if( $nextId ) echo "<a href='main.php?script=showpost&mid=$nextId' class='bl_main'> Next &gt;</a>";
	else echo "<a class='bl_main_grey'> Next &gt;</a>";
?>
<script type="text/javascript">
	SyntaxHighlighter.config.bloggerMode = true;
	SyntaxHighlighter.config.clipboardSwf = '../forums/clipboard.swf';
	SyntaxHighlighter.all();
</script>