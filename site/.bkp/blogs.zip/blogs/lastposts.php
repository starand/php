<?
	if( !defined("COMMON") ) die();
	include_once "blogs.php";
	
	$mlist = GetUserMsgs( $_SESSION['userId'] );
?>
<div style='font-size:20px;color:#33ee44;'>Last Posts</div>
<div class='frmframe'><table class='frmlist' cellspacing='1'>
<tr class='frmttl'><td class='padding'><span>Post</span> <span style='float:right;'>Date</span></td></tr>
<?
	$i = 1;
	if( $mlist ) foreach( $mlist as $msg )
	{
		echo "<tr style='background:#".($i++%2 ? "282828" : "333333")."' ><td>".ShowPreviev($msg)."</td></tr><tr></tr>";
	}
	else
	{
		echo "<tr style='background:#".($i%2 ? "282828" : "333333")."'><td><div>No record here</div></td></tr>";
	}
?>

</table></div>

