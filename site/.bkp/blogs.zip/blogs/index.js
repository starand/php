var load = "<frameset rows='*,0' frameborder='0' border='0'><frame name='main' src='blogs/main.php'><frame name=actions src='about:blank' noresize></frameset>";
document.write( load );
