<? include_once "common.php" ?>
<HEAD>
	<LINK href='../blog/blog.css' rel='stylesheet' type='text/css' />
	<meta http-equiv='Content-Type' content='text/html; charset=windows-1251'>
</HEAD>

<script src='/blog/js/jquery.js'></script>

<DIV id='content' class='content'>
	
</DIV>

<script>
$(document).ready(function()
{
	$( "#content" ).load( "../blog/content.php" );
});
</script>