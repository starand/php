<?
####Common function
function CRITICAL_ERROR( $msg )
{
	die( $msg );
}

###### Msg Functions
function GetMessage( $mid )
{
	$sql = "SELECT * FROM knowbase.msgs WHERE mId=$mid";
	$res = uquery( $sql );
	if( $res && mysql_num_rows($res) ) return mysql_fetch_array( $res );
	return 0;
}

##### Stream Functions
function AddStream( $name, $desc, $pid = 0 )
{
	$sql = "INSERT INTO blog_streams VALUES( NULL, '$name', '$desc', $pid )";
	return uquery( $sql );
}

function GetStreams( $pid )
{
	$sql = "SELECT * FROM blog_streams WHERE bsPid=$pid";
	$res = uquery( $sql ); if( !$res || !mysql_num_rows($res) ) return 0;
	
	for( $result = array(); $row = mysql_fetch_array($res); $result[] = $row );
	return $result;
}

?>