create table blog_msgs
(
  bmId int unsigned not null auto_increment primary key,
  bmUid int unsigned not null,
  bmPublidDate datetime not null,
  bmEditTime datetime not null,
  bmStreamId int unsigned not null,
  bmTheme varchar(255) not null,
  bmMsg mediumtext not null,
  bmOrigMsg mediumtext not null,
  bmViewCount int unsigned not null,
  fulltext ket( bmMsg )
);

create table blog_streams
(
  bsId int unsigned not null auto_increment primary key,
  bsName varchar(30) not null,
  bsDesc varchar(255) not null,
  bsPid int unsigned not null
);