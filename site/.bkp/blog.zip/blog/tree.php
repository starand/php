<?
	include_once "common.php";
?>
<br>
<div id='tree-content'></div>

<script>
$(document).ready(function()
{
	$( "#tree-content" ).load( "../blog/substreams.php?pid=0" );
});

function LoadStreamList( pid )
{
	$( "#sub-streams"+pid ).load( "../blog/substreams.php?pid="+pid );
}
</script>