<?
	define( "BLOG_ROOT", "e:/lab/.site/www/blog/" );
	include_once BLOG_ROOT."../files/common.php";
	include_once BLOG_ROOT."functions.php";
	
?>