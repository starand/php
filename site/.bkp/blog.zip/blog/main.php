<?
	include_once "common.php";
?>
<table class='main'>
<tr>
	<td class='tree' id='tree'></td>
	<td class='topic-content' id='topic-content'></td>
</tr>
</table>

<script>
$(document).ready(function()
{
	$( "#tree" ).load( "../blog/tree.php" );
	$( "#topic-content" ).load( "../blog/news.php" );
});
</script>