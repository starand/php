<? 
	include_once "common.php";
	include_once BLOG_ROOT."top.php";
	
	//AddStream( "C++", "C++, STL, Boost ..", 1 );
?>
<BR><BR>
<DIV id='main' class='main'>

</DIV>

<script>
$(document).ready(function()
{
	$( "#main" ).load( "../blog/main.php" );
});
</script>