<?
	include_once "common.php";
	if( !isset($_GET['pid']) ) CRITICAL_ERROR( "Unable to load sub streams" );
	
	$streams = GetStreams( (int)$_GET['pid'] );
	if( !$streams )
	{
		CRITICAL_ERROR( "Unable to load streams tree" );
	}
	
	echo "<table class='tree'>";
	foreach( $streams as $stream )
	{
		echo "<tr>
				<td style='width:10px;'> </td>
				<td nowrap>
					<a class='tree-item' title='{$stream['bsDesc']}' onclick='LoadStreamList({$stream['bsId']});'>
						<img src='../blog/img/open-stream.png'>{$stream['bsName']}
						<div id='sub-streams{$stream['bsId']}'></div>
					</a>
				</td>
			</tr>";
	}
	echo "</table>";
	
?>
