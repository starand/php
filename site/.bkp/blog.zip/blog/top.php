<DIV class='top'>

<table class='top'>
	<tr style='height:27px;'>
		<td>
			<span class='top'>StarAnd Blog</span>
		</td>
		<td style='text-align: right;'>
			<a href='../users/enter.php?enter=1' style='font-size: 12px; text-decoration:none;'>����</a>
		</td>
	</tr>

	<tr>
		<td>
			<table class='menu'>
				<tr>
					<td> ������� &nbsp; </td>
					<td> ������ &nbsp; </td>
					<td> ��������� &nbsp; </td>
					<td> ������� &nbsp; </td>
				</tr>
			</table>
		</td>
		<td style='text-align: right;'>
			<form>
				<input name='query' type='text' maxlength='200' class='search-box'/><button value='' type='submit' class='search-button'>
				<img src='../blog/img/search.png'> </button>
			</form>
		</td>		
	</tr>
	<tr class='space-line'><td colspan='2'></td></tr>
</table>

</DIV>
